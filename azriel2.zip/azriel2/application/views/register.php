<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo base_url ('assets/styles.css')?>"> 
    <title>Document</title>
</head>
<body>
<div class="bg-info" id= "container">
 <div class= "card border shadow-lg p-3 mb-5 bg-body rounded" id="kartu2">
  <h1> REGISTER </h1> <br> <br> 
   <div class="input-group">
    <span class="input-group-text bg-dark text-info">NIS</span>
     <input type="text" aria-label="First name" class="form-control"  name="NIS">
      </div><br>
       <div class="input-group" >
        <span class="input-group-text bg-dark text-info">NAME</span>
         <input type="text" aria-label="First name" class="form-control" name="NAMA">
          </div><br>
          <div class="input-group" >
        <span class="input-group-text bg-dark text-info">CLASS</span>
         <input type="text" aria-label="First name" class="form-control" name="NAMA">
          </div><br>
          <div class="input-group" >
        <span class="input-group-text bg-dark text-info">NEW PASSWORD</span>
         <input type="text" aria-label="First name" class="form-control" name="NAMA">
          </div><br>
           <br>
            <input type="submit" class="btn btn-outline-info" value="REGISTER" name="proses"></input> <br> <br>
            <a class="text-info" href="login">already have an account?</a>
            
</div>
</div>
</body>
</html>