<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class signup extends CI_Controller {

	public function index()
	{
		echo "kamu jelek";
    }
	public function signup() {
		echo "HALAMAN DAFTAR";
	}
}
